#include <iostream>
#include "memoire_borne.h"
#include "donnees_borne.h"
#include "lecteurcarte.h"
#include "BaseClients.h"
#include "voyants.h"

int main()//Prog principale
{
    LecteurCarte lecteur_carte; // Cree un objet lecteur_carte de type LecteurCarte
    while (1)// boucle infinie
    {
        //Appel aux fonctions de la classe lecturecarte
        lecteur_carte.initialiser();
        lecteur_carte.lire_carte();
    }
}

