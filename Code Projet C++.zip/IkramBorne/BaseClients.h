#ifndef BASECLIENTS_H_
#define BASECLIENTS_H_
//Definition des constantes
#define CARTE_TROUVEE 1
#define CARTE_NON_TROUVEE 0
#define ERROR_FICHIER -1

class BaseClient
{
  public : 
	  int baseclients_authentifier(int num_carte);
    int baseclients_reprise(void);
    void baseclients_get_client(void);
};

#endif
