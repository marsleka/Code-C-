#ifndef LECTEUR_CARTE_H
#define LECTEUR_CARTE_H
#include <lcarte.h>

#define ADMIN 1
#define AUTONTIFICATION_OK  1

class LecteurCarte
{
  public : 
	void initialiser();
	void lire_carte();
};

#endif
