
#include <stdlib.h>
#include <stdio.h>
#include <lcarte.h>
#include <unistd.h>
#include "timer.h"
#include <memoire_borne.h>
#include <donnees_borne.h>
#include <mem_sh.h>
#include <donnees.h>
#include "recharge.h"
#include "voyants.h"
#include <iostream>

int Time;
voyants Voyants;

//Fonction de recharge de mon Tesla
int recharge::Recharge()
{ 
	int state;
	io=acces_memoire(&shmid); //Accès mémoire
	attente_retrait_carte(); //attente retrait carte
	Voyants.clignoteCharge(VERT);
	timer_initialiser();//Gestion timer
	Time= timer_valeur();
	while (io -> bouton_charge!=1 || Time>=6)
	{
		Time= timer_valeur();
	}
	if(Time<15)
	{
		Voyants.eteindreDispo(OFF); //Gestion des LEDS
		Voyants.allumerCharge(ROUGE);
		Voyants.allumerTrappe(VERT);
		io->gene_pwm=DC; //io->gene_u=12;
		state = 1;
	}
	if(Time>=15)
	{
                Voyants.allumerDispo(VERT);
                state=2;
                return state;
	}
	//std::cout<<"Time==== :"<< Time <<std::endl;
	return state;
}

//Fonction de charge de ma Tesla
void recharge::charge()
{
	io=acces_memoire(&shmid);
	while((io->gene_u)!=9)
	usleep(1000);
	Voyants.eteindreTrappe(OFF);
	Voyants.allumerPrise(VERT);
	sleep(1);
	io->gene_pwm=AC_1K;
	sleep(1);
	//io->gene_u=6;
	sleep(1);
	io->contacteur_AC=1;
	io->gene_pwm=AC_CL;
	sleep(1);
	while((io->gene_u)!=9)
	{
		sleep(1);
                std::cout<<"En charge la voiture Tesla"<<std::endl;
		if(io->bouton_stop==1)
		io->gene_u=9;
	}
	io->contacteur_AC=0;
	io->gene_pwm=DC;
	io->gene_u=9;
	Voyants.allumerCharge(VERT);
}

//Fonction recuperation Voiture Tesla 
void recharge::recup()
{
	io=acces_memoire(&shmid);
	Voyants.allumerTrappe(VERT);
	while((io->gene_u)!=12)
	usleep(1000);
	Voyants.eteindreTrappe(OFF);
	Voyants.allumerPrise(OFF);
	Voyants.allumerCharge(OFF);
	Voyants.allumerDispo(VERT);
}
