#include "voyants.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
//#include "timer.h"
#include <memoire_borne.h>
#include <donnees_borne.h>
#include <mem_sh.h>
#include <donnees.h>
#include <lcarte.h>

entrees *io;
 int shmid;
 //int time;
//Fonction Initialisations voyants
void voyants::init()
{
	io = acces_memoire(&shmid);
}
//Fonction clignote voyants par defaut
void voyants::clignoteDefault(led couleur)
{	
	int i;	
	for(i=0;i<4;i++)
	{
		io-> led_defaut=couleur;
		sleep(1);
		io->led_defaut=OFF;
		sleep(1);
	}
}
//Fonction clignote led de Charge
void voyants::clignoteCharge(led couleur)
{	
	int i;
	for(i=0;i<4;i++)
	{
	io-> led_charge=couleur;
	sleep(1);
	io->led_charge=OFF;
	sleep(1);
	}
}
//Fonction eteindre led Dispo
void voyants::eteindreDispo(led couleur)
{
	io->led_dispo=OFF;
}
//Fonction allumer led de Charge
void voyants::allumerCharge(led couleur)
{
	io-> led_charge=couleur;
}
//Fonction allumer led Trappe
void voyants::allumerTrappe(led couleur)
{
	io-> led_trappe=couleur;
}
//Fonction allumer led Dispo
void voyants::allumerDispo(led couleur)
{
	io-> led_dispo=couleur;
}
//Fonction eteindre led Trappe
void voyants::eteindreTrappe(led couleur)
{
	io-> led_trappe=couleur;
}
//Fonction allumer Prise
void voyants::allumerPrise(led couleur)
{
	io-> led_prise=couleur;
}

