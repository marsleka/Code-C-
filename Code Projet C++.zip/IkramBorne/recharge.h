#ifndef RECHARCHE_H
#define RECHARCHE_H

#include <stdio.h>
#include <donnees_borne.h>
#include <memoire_borne.h>

//entrees *io;
//int shmid;

class recharge
{
    public:
        int Recharge();
        void charge();
        void recup();
};

#endif
