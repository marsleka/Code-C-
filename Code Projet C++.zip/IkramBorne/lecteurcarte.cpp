
#include "lecteurcarte.h"
#include <iostream>
#include <lcarte.h>
#include "BaseClients.h"
#include "voyants.h"
#include "recharge.h"
#include <fstream> // Bibliothèque pour gérer les fichiers


using namespace std;
int state;

//Fonction d'initialisation
void LecteurCarte::initialiser()
{
	initialisations_ports();
}

//Fonction pour lire la carte
void LecteurCarte::lire_carte()
{
	BaseClient BaseClient;
	voyants voyants;
	recharge recharge;
	std::string password;
	std::string passe="ikram";
	std::string Mot;
	std :: string mot ;
	
	int Mode;
	std::cout<<"Inserer votre carte svp !! :"<<std::endl;
	std::cout<<"Entrez le mode choisis :"<<std::endl;
        std::cout<<"0 si vous etes Client \net 1 si vous etes Administrateur :"<<std::endl;
	std :: cin >> Mode ;

	if(Mode==ADMIN) // Administrateur
	{ 
		// Continuer la boucle indéfiniment jusqu'à ce que le mot de passe soit correct
		do 
		{
			std::cout << "ok Mr/Mme admin Entrez le mot de passe svp: ";
			std :: cin >> mot ;
			if (mot == passe) // Si le mot de passe est correct
			{
				std::cout << "Accès autorisé !! " << std :: endl;
				break; // Sortir de la boucle car le mot de passe est correct
			} 
			else // le mot de passe est incorrect
			{
				std::cout << "aye aye aye Réessayez Mot de passe incorrect !!! " << std :: endl;
			}
		} while (true); 
		
		// Ouverture du fichier en mode ecriture
		std::ofstream fichier("ikram.txt", std::ios::app); 
		if (fichier.is_open()) 
		{
			int valeur;

			std::cout << "Veuillez saisir un numero de carte et -1 si vous voulez arrêter la saisie : ";
			while (std::cin >> valeur && valeur != -1)
			{
				fichier << valeur << std::endl; // Écriture de la valeur dans le fichier
				std::cout << "Num Bien enregistrée et -1 si vous voulez arrêter la saisie : ";
			}
			fichier.close(); // Fermeture du fichier
			std::cout << "Les nums enregistrées avec succès dans le fichier !" << std::endl;
		}  
		else  // Ouverture du fichier impossi maymkench
		{
			std::cerr << "Impossible d'ouvrir le fichier : Erreur lors de l'ouverture du fichier.txt" << std::endl;
		}
	}
	
        std::cout << "Bonjour Mr/Mme le/la Client(e)  ";
	// Appel a la Fonction pour attendre l'insersion de la carte			
	attente_insertion_carte();
	int numero = lecture_numero_carte(); //lire le num de la carte inseré
	std::cout<<"Le Numéro de la carte est :"<< numero <<std::endl; // affichage du num de la carte inseree
	int autontification = BaseClient.baseclients_authentifier(numero);
	if(autontification == AUTONTIFICATION_OK) // Si autontification est bien passe 
	{ 
		std::cout<<"Authentification reussite:"<<std::endl;
		voyants.init();
		voyants.clignoteCharge(VERT);
		state = recharge.Recharge();
		if(state==1)
		{
			recharge.charge();
                        recharge.recup(); //appel a la fonction pour recuperer la voiture
		}
		if(state==2) 
		{ 
			std::cout<<"Appuyer sur le Button charge SVP :"<<std::endl;		
		}
	}
	else // Si autontification est non reussit
	{ 
		std::cout<<"Numero de votre carte n'es pas dans notre base de doneees:"<<std::endl;
		voyants.init();
		voyants.clignoteDefault(ROUGE);
		voyants.allumerDispo(VERT);		
	}         
    //Appel a la Fonction pour attendre le retrait de la carte      
    attente_retrait_carte();
    //Appel a la Fonction pour libirer les ports
    liberation_ports();
 }
