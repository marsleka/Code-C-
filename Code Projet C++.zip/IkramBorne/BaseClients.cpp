#include "BaseClients.h"
#include <iostream>
#include <fstream>
#include <vector>


int BaseClient::baseclients_authentifier(int num_carte)
{
    int num;
    std::vector<int> valeurs; // Vecteur de "int" pour stocker les valeurs lues du fichier.txt

    // Ouvrir le fichier ikram.txt en mode lecture qui contient les numeros de carte
    std::ifstream fichier("ikram.txt");
    if (fichier.is_open()) //Fichier ouvert avec sucess
    {
        while (fichier >> num) // Lecture des valeurs du fichier
        { 
            valeurs.push_back(num); // Ajout de la num lu au vecteur
        }
        fichier.close(); // Fermer le fichier.txt

        for (int val : valeurs) 
        {
            if (num_carte == val) 
            {
                return CARTE_TROUVEE; // C'est bon le Numero de carte trouvée dans le fichier.txt
            }
        }
        return CARTE_NON_TROUVEE; // Dommage le Numero de carte non trouvée dans le fichier.txt
    } 
    else 
    {
        std::cerr << "Impossible d'ouvrir le fichier : Erreur lors de l'ouverture du fichier.txt " << std::endl;
        return ERROR_FICHIER;
    }
}